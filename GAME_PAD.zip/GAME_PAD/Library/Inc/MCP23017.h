#ifndef MCP23017_H
#define MCP23017_H

#include "stm32f1xx_hal.h"

#define MCP23017_ADDR     (0x20 << 1)
#define IODIRA_REG        0x00
#define GPIOA_REG         0x12
#define IODIRB_REG        0x01
#define GPIOB_REG         0x13

void MCP23017_Init(I2C_HandleTypeDef *hi2c);
uint8_t MCP23017_Read_GPIOA(I2C_HandleTypeDef *hi2c);
uint8_t MCP23017_Read_GPIOB(I2C_HandleTypeDef *hi2c);
void MCP23017_WriteRegister(I2C_HandleTypeDef *hi2c, uint8_t reg, uint8_t value);
void MCP23017_EnablePullUps(I2C_HandleTypeDef *hi2c);

#endif
